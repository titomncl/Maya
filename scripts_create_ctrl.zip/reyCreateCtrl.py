#!/usr/bin/env python
# -*- coding: utf-8 -*-

import maya.api.OpenMaya as om
import maya.OpenMaya as om_old
import maya.cmds as mc
import pickle
import os
import math


# ------------------------------------------------------ #
# ###################################################### #
#                                                        #
#                  Create ctrl tool                      #
#                                                        #
# ###################################################### #
# ------------------------------------------------------ #

# LOADING SCRIPT :
# import reyCreateCtrl
# reload(reyCreateCtrl)
# lst_allListedMaterials = reyCreateCtrl.showreyCreateCtrlPannel()
# 
# Reynald Bayeux
# bayeux_reynald@yahoo.fr
# 02/11/2020

# ----- Load the ctrl dictionnaire file -----#
str_ctrlDictFolder = "{}/ctrlDictFolder/".format(os.path.dirname(os.path.abspath(__file__)).replace('\\', '/'))

str_ctrlDictFile = "{}ctrlDictionnaireFile.txt".format(str_ctrlDictFolder)
# ! insert check or dict exists

with open(str_ctrlDictFile, "rb") as ctrlFile:
    monDepickler = pickle.Unpickler(ctrlFile)
    ctrlDictionnaire = monDepickler.load()


def showreyCreateCtrlPannel():

    # ----- Name and detect existing windows ----- #
    windowName = "reyCreateCtrlWindow"
    dockName = "reyCreateCtrlDoc"

    if mc.dockControl(dockName, ex=True):
        mc.deleteUI(dockName)
    if mc.window(windowName, ex=True):
        mc.deleteUI(windowName)

    # ----- Create contening windows and frames ----- #
    reyCreateCtrlWindow = mc.window(windowName, title="Rey Utilities Window")
    mc.showWindow( reyCreateCtrlWindow )

    # ------------------------------------------------------------------- #
    # ------------------------------------------------------------------- #
    # --------------------------- Make content -------------------------- #
    # ------------------------------------------------------------------- #
    # ------------------------------------------------------------------- #

    

    # ------------------- #
    # ----- rig Tab ----- #
    # ------------------- #

    # ----- create Ctrl ----- #
    mc.frameLayout("createCtrlFrame", label="create ctrl", cll=False, w=400, parent="reyCreateCtrlWindow", cl=True)

    mc.flowLayout("ctrlNameFlow", columnSpacing=5, parent="createCtrlFrame")
    mc.text(label='ctrl name', parent="ctrlNameFlow")
    mc.textField("ctrlNameTextField", w=300, parent="ctrlNameFlow")

    mc.flowLayout("ctrlScaleFlow", columnSpacing=5, parent="createCtrlFrame")
    mc.text(label='ctrl scale factor', parent="ctrlScaleFlow")
    mc.floatField("ctrlScaleFloatField", value=1, w=100, parent="ctrlScaleFlow")

    mc.checkBox("ctrlNumberCheckBox", label='Increment', parent="createCtrlFrame")

    mc.button(label="New ctrl shape", command=("reyCreateCtrl.ctrlDictionnaire=reyCreateCtrl.NewCtrlShape()"), parent="createCtrlFrame")

    scrollLayout = mc.scrollLayout("createCtrlScroll", horizontalScrollBarThickness=16, verticalScrollBarThickness=16, h=550, parent="createCtrlFrame")

    mc.gridLayout("radioCtrlTypeLayout", numberOfColumns=3, cellWidthHeight=(125, 125), parent="createCtrlScroll")
    # mc.radioCollection("radioCtrlTypeRadio", parent="radioCtrlTypeLayout")

    for obj in ctrlDictionnaire:
        str_iconePath = "{}{}.png".format(str_ctrlDictFolder, obj)
        mc.symbolButton("{}SymbolButton".format(obj), image=str_iconePath, c='reyCreateCtrl.createCtrl(givenName="", str_givenlShape="{}", float_scaleFactor=None)'.format(obj), parent="radioCtrlTypeLayout")
        mc.popupMenu("{}PopupMenu".format(obj), parent="{}SymbolButton".format(obj))
        mc.menuItem("{}ReplaceMenuItem".format(obj), label='Replace Shape', c='reyCreateCtrl.ctrlDictionnaire=reyCreateCtrl.ReplaceCtrlShape("{0}")'.format(obj), parent="{}PopupMenu".format(obj))
        mc.menuItem("{}DeleteMenuItem".format(obj), label='Delete Shape', c='reyCreateCtrl.ctrlDictionnaire=reyCreateCtrl.DeleteCtrlShape("{}")'.format(obj), parent="{}PopupMenu".format(obj))


# ------------------------------------------------------------------- #
# ------------------------------------------------------------------- #
# -------------------------- Make functions ------------------------- #
# ------------------------------------------------------------------- #
# ------------------------------------------------------------------- #



# ----------------------- #
# ----- create ctrl ----- #
# ----------------------- #


def createCtrl(givenName="", str_givenlShape="", float_scaleFactor=None):
    targetList = mc.ls(sl=True, fl=True)

    # check if an object is selected in vueport
    if len(targetList) == 0:
        mc.group(n="emptyTargetList", empty=True)
        targetList = ["emptyTargetList"]

    # check if user give a name
    if len(givenName) == 0:
        nameValue = mc.textField("ctrlNameTextField", q=True, tx=True)
    else:
        nameValue = givenName

    if len(nameValue) == 0:
        nameValue = False

    numberCheck = mc.checkBox("ctrlNumberCheckBox", query=True, v=True)

    str_ctrlShape = str_givenlShape

    if not float_scaleFactor:
        float_scaleFactor = mc.floatField("ctrlScaleFloatField", value=1, q=True)

    i = 0
    for target in targetList:
        if nameValue:
            name = nameValue
        else:
            name = target

        if numberCheck:
            increment = "_" + str(i)
        else:
            increment = ""

        mc.select(cl=True)
        position = mc.xform(target, q=True, t=True, ws=True)
        rotation = mc.xform(target, q=True, ro=True, ws=True)

        # jointName = mc.joint(n=name+"_"+str(i)+"_jnt", rad=0.1)
        # mc.xform(jointName, t=position, ws=True)
        ctrlOffset = mc.group(n="ctrl_" + name + increment + "_grp", em=True)
        mc.xform(ctrlOffset, t=position, ro=rotation, ws=True)
        ctrlCurve = mc.curve(n="ctrl_" + name + increment + "_crv", d=1, p=(ctrlDictionnaire[str_ctrlShape]))

        strLst_shapeName = mc.listRelatives(ctrlCurve, s=True)
        str_shapeName = strLst_shapeName[0]
        mc.setAttr(str_shapeName + ".isHistoricallyInteresting", 0)

        mc.scale(float_scaleFactor, float_scaleFactor, float_scaleFactor, ctrlCurve, absolute=True)
        mc.makeIdentity(ctrlCurve, apply=True, scale=True)
        mc.xform(ctrlCurve, t=position, ro=rotation, ws=True)
        mc.parent(ctrlCurve, ctrlOffset)
        i += 1
    if mc.objExists("emptyTargetList"):
        mc.delete("emptyTargetList")

    return(ctrlOffset, ctrlCurve)


def NewCtrlShape():
    with open(str_ctrlDictFile, "rb") as ctrlFile:
        monDepickler = pickle.Unpickler(ctrlFile)
        ctrlDictionnaire = monDepickler.load()

    cvPositionList = []
    cvList = mc.ls(sl=True, fl=True)
    mc.select(cl=True)
    for cv in cvList:
        cvPos = mc.xform(cv, q=True, t=True, ws=True)
        cvPositionList.append(cvPos)

    nameValue = mc.textField("ctrlNameTextField", q=True, tx=True)
    ctrlDictionnaire[nameValue] = cvPositionList

    with open(str_ctrlDictFile, "wb") as ctrlFile:
        monPickler = pickle.Pickler(ctrlFile)
        monPickler.dump(ctrlDictionnaire)

    # create interface button
    createCtrlIcons(nameValue, cvPositionList)
    str_iconePath = "{}{}.png".format(str_ctrlDictFolder, nameValue)
    mc.symbolButton("{}SymbolButton".format(nameValue), image=str_iconePath, c='reyCreateCtrl.createCtrl(givenName="", str_givenlShape="{}", float_scaleFactor=None)'.format(nameValue), parent="radioCtrlTypeLayout")
    mc.popupMenu("{}PopupMenu".format(nameValue), parent="{}SymbolButton".format(nameValue))
    mc.menuItem("{}ReplaceMenuItem".format(nameValue), label='Replace Shape', c='reyCreateCtrl.ctrlDictionnaire=reyCreateCtrl.ReplaceCtrlShape("{0}")'.format(nameValue), parent="{}PopupMenu".format(nameValue))
    mc.menuItem("{}DeleteMenuItem".format(nameValue), label='Delete Shape', c='reyCreateCtrl.ctrlDictionnaire=reyCreateCtrl.DeleteCtrlShape("{}")'.format(nameValue), parent="{}PopupMenu".format(nameValue))


    return ctrlDictionnaire


def ReplaceCtrlShape(str_ctrlShape):
    with open(str_ctrlDictFile, "rb") as ctrlFile:
        monDepickler = pickle.Unpickler(ctrlFile)
        ctrlDictionnaire = monDepickler.load()

    cvPositionList = []
    cvList = mc.ls(sl=True, fl=True)
    print(cvList)
    mc.select(cl=True)
    for cv in cvList:
        cvPos = mc.xform(cv, q=True, t=True, ws=True)
        cvPositionList.append(cvPos)

    ctrlDictionnaire[str_ctrlShape] = cvPositionList

    with open(str_ctrlDictFile, "wb") as ctrlFile:
        monPickler = pickle.Pickler(ctrlFile)
        monPickler.dump(ctrlDictionnaire)

    createCtrlIcons(str_ctrlShape, cvPositionList)

    str_iconePath = "{}{}.png".format(str_ctrlDictFolder, str_ctrlShape)
    mc.symbolButton("{}SymbolButton".format(str_ctrlShape), image=str_iconePath, e=True)
    return ctrlDictionnaire


def DeleteCtrlShape(str_ctrlShape):
    with open(str_ctrlDictFile, "rb") as ctrlFile:
        monDepickler = pickle.Unpickler(ctrlFile)
        ctrlDictionnaire = monDepickler.load()

    del ctrlDictionnaire[str_ctrlShape]

    with open(str_ctrlDictFile, "wb") as ctrlFile:
        monPickler = pickle.Pickler(ctrlFile)
        monPickler.dump(ctrlDictionnaire)

    mc.deleteUI("{}SymbolButton".format(str_ctrlShape))
    return ctrlDictionnaire


def createCtrlIcons(str_ctrlShape, cvPositionList):
    # DEBUT DE MULTIPLICATION PAR MATRIX
    # str_selectedObj = mc.ls(sl=True, fl=True)[0]
    # m_transformMatrix = om.MMatrix(mc.xform(str_selectedObj, q=True, m=True, ws=True))
    lst_defaultXformMatrix = [0.7071067811865475, -5.551115123125783e-17, -0.7071067811865475, 0.0,
                              -0.5, 0.7071067811865475, -0.49999999999999994, 0.0,
                              0.49999999999999994, 0.7071067811865475, 0.4999999999999999, 0.0,
                              33.82737545441062, 47.83913314711423, 33.82737545441062, 1.0]

    m_transformMatrix = om.MMatrix(lst_defaultXformMatrix)
    m_reverseTransformMatrix = m_transformMatrix.inverse()

    lst_points = []
    for lst_point in cvPositionList:
        m_pointPosition = om.MMatrix((1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, lst_point[0], lst_point[1], lst_point[2], 1.0))

        m_transformedPoint = m_pointPosition * m_reverseTransformMatrix
        lst_points.append([m_transformedPoint[12], m_transformedPoint[14] * -1])

    # DEBUT DE CETTE CLASSE
    int_textureResolution = 120
    # PART 11
    # check for extremes
    lst_extremeMin = [lst_points[0][0], lst_points[0][1]]
    lst_extremeMax = [lst_points[0][0], lst_points[0][1]]

    for lst_position in lst_points:
        if lst_position[0] < lst_extremeMin[0]:
            lst_extremeMin[0] = lst_position[0]
        if lst_position[1] < lst_extremeMin[1]:
            lst_extremeMin[1] = lst_position[1]

        if lst_position[0] > lst_extremeMax[0]:
            lst_extremeMax[0] = lst_position[0]
        if lst_position[1] > lst_extremeMax[1]:
            lst_extremeMax[1] = lst_position[1]

    # get the scale factor
    lst_extremeMax = [lst_extremeMax[0] - lst_extremeMin[0], lst_extremeMax[1] - lst_extremeMin[1]]
    if lst_extremeMax[0] > lst_extremeMax[1]:
        float_scaleFactor = (int_textureResolution - 10) / lst_extremeMax[0]
        lst_offset = [5, (int_textureResolution - (lst_extremeMax[1] * float_scaleFactor)) / 2]
    else:
        float_scaleFactor = (int_textureResolution - 10) / lst_extremeMax[1]
        lst_offset = [(int_textureResolution - (lst_extremeMax[0] * float_scaleFactor)) / 2, 5]

    # set all points to 0 min , multiply by scale factor, add offset
    for i in range(len(lst_points)):
        lst_points[i][0] = ((lst_points[i][0] - lst_extremeMin[0]) * float_scaleFactor) + lst_offset[0]
        lst_points[i][1] = ((lst_points[i][1] - lst_extremeMin[1]) * float_scaleFactor) + lst_offset[1]

    # PART 12
    # determine tous les vertex
    # Scan Horisontal
    lst_pointsHorisontal = []
    for i in range(len(lst_points) - 1):

        # ajoute le premier point a la liste
        lst_pointsHorisontal.append(lst_points[i])

        # calcul de la longueur du cote adjacent
        float_refAdj = lst_points[i + 1][0] - lst_points[i][0]

        # calcul de la longueur du cote oppose
        float_refOpp = lst_points[i + 1][1] - lst_points[i][1]

        if not float_refAdj == 0:
            float_tanAngle = float_refOpp / float_refAdj

            # pour tous les points dans la longueur du cote adjacent
            for float_newAdj in range(1, int(math.sqrt(pow(float_refAdj, 2))) + 1):
                if float_refAdj < 0:
                    float_newAdj *= -1
                # calcul de la longueur du nouveau cote oppose
                float_newOpp = float_newAdj * float_tanAngle
                # ajout des valeurs et creation du point
                float_newX = float_newAdj + lst_points[i][0]
                float_newY = float_newOpp + lst_points[i][1]

                # ahoute le point en cours à la liste
                lst_pointsHorisontal.append([float_newX, float_newY])

    # ajoute le dernier point à la liste
    lst_pointsHorisontal.append(lst_points[-1])

    # SCAN VERTICAL
    lst_pointsVertical = []
    for i in range(len(lst_pointsHorisontal) - 1):
        # ajoute le premier point a la liste
        lst_pointsVertical.append(lst_pointsHorisontal[i])

        # calcul de la longueur du cote oppose
        float_refOpp = lst_pointsHorisontal[i + 1][1] - lst_pointsHorisontal[i][1]

        if math.sqrt(pow(float_refOpp, 2)) > 1:
            # pour tous les points dans la longueur du cote adjacent
            for float_newOpp in range(1, int(math.sqrt(pow(float_refOpp, 2))) + 1):
                if float_refOpp < 0:
                    float_newOpp *= -1
                # ajout des valeurs et creation du point
                float_newX = lst_pointsHorisontal[i][0]
                float_newY = lst_pointsHorisontal[i][1] + float_newOpp

                # ahoute le point en cours à la liste
                lst_pointsVertical.append([float_newX, float_newY])

    # ajoute le dernier point à la liste
    lst_pointsVertical.append(lst_points[-1])

    # PART 13 : trace picture

    lst_pixelValues = [0, 0, 0, 0] * int_textureResolution * int_textureResolution
    lst_pixelColor = [100, 135, 255, 255]

    for lst_point in lst_pointsVertical:
        int_pixelIndex = (int(lst_point[0]) * 4) + (int(lst_point[1]) * 4 * int_textureResolution)

        for i in range(4):
            lst_pixelValues[i + int_pixelIndex] = lst_pixelColor[i]

    lImage = om_old.MImage()
    lImage.create(int_textureResolution, int_textureResolution)

    lPixels = lImage.pixels()

    for i in range(len(lst_pixelValues)):
        om_old.MScriptUtil.setUcharArray(lPixels, i, lst_pixelValues[i])

    lOutImage = om_old.MImage()
    lOutImage.setPixels(lPixels, int_textureResolution, int_textureResolution)

    str_iconePath = "{}{}.png".format(str_ctrlDictFolder, str_ctrlShape)
    lOutImage.writeToFile(str_iconePath, "png")

